package excepciones;

public class EmailInvalidoException extends Exception {
    public EmailInvalidoException(String message) {
        super(message);
    }
}

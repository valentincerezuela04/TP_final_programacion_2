package excepciones;

public class ContrasenaInvalidaException extends Exception {
    public ContrasenaInvalidaException(String message) {
        super(message);
    }
}

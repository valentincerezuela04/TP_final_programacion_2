package contenido;

public enum EstadoVisto {
    VISTO,NO_VISTO
}

package contenido;

public enum EstadoEmision {
    EMISION,ABANDONADO,FINALIZADO
}
